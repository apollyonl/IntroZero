Pinturas rupestres es una pagina web diseñada para mostrar los 3 mejores pintores a criterio propio
En la creacion de esta pagina web se utilizaron herramientas como Scss, Bootstrap y css. 
las biografias.html contienen información acerca de los pintores elegidos.
Las obras.html contienen imagenes de algunas de las obras de cada pintor.